package com.example.admintable
//
//import androidx.compose.material.icons.Icons
//import androidx.compose.material.icons.filled.AccountCircle
//import androidx.compose.material.icons.filled.Home
//import androidx.compose.material.icons.filled.Person
//import androidx.compose.ui.graphics.vector.ImageVector
//import androidx.compose.ui.res.painterResource
//
//sealed class Screen (
//    val route: String,
//    val name: String,
//    val iconName: String // Resource name without file extension
//) {
//    object Home : Screen(route = "home_screen", name = "Home", iconName = "home")
//    object Table: Screen(route = "table_screen", name = "Table", iconName = "table1")
//    object Dish: Screen(route = "dish_screen", name = "Menu", iconName = "dish")
//    object Order: Screen(route = "Order_screen", name = "Order", iconName = "order")
//}
